// EDIT THIS FILE to update the dashboard. Keep the structure; save; refresh index.html.
window.PROFILE = {
  "profile": {
    "name": "Dr. Naheem K. T.",
    "title": "Professional Assistant, Central Library, Pondicherry University",
    "focus": "Scientometrics and bibliometrics | Webometrics | Research data repositories | Library automation | Research support and metadata",
    "email": "naheem.lib@pondiuni.ac.in",
    "photo": "photo.jpg",
    "ids": [
      {
        "label": "ORCID",
        "value": "0000-0002-0623-8090",
        "url": "https://orcid.org/0000-0002-0623-8090"
      },
      {
        "label": "Web of Science",
        "value": "AAG-3056-2020"
      },
      {
        "label": "Scopus",
        "value": "56288763900"
      },
      {
        "label": "Google Scholar",
        "value": "0gU3V18AAAAJ"
      }
    ],
    "about": [
      "Library professional with over 19 years of service at Pondicherry University, IIT Madras, and the Institute of Human Resources Development (IHRD), Kerala. Specializes in technical processing, library automation, research support, and digital resource management.",
      "Manages faculty research data for NAAC and NIRF reporting and helped implement the VIDWAN–IRINS portal for faculty research profiling."
    ]
  },
  "metrics": {
    "asOf": "3 November 2026",
    "rows": [
      {
        "db": "Scopus",
        "id": "56288763900",
        "pubs": 9,
        "cites": 157,
        "h": 4
      },
      {
        "db": "Web of Science",
        "id": "AAG-3056-2020",
        "pubs": 9,
        "cites": 88,
        "h": 3
      },
      {
        "db": "Google Scholar",
        "id": "0gU3V18AAAAJ",
        "pubs": 43,
        "cites": 394,
        "h": 8
      }
    ]
  },
  "publications": [
    {
      "type": "journal",
      "year": 2025,
      "authors": "Subaveerapandiyan, A.; Naheem, K. T.; Shimray, Somipam R.",
      "title": "Understanding copyright anxiety among Indian library professionals",
      "source": "Journal of Librarianship and Information Science",
      "scopus": 0,
      "wos": 0,
      "doi": "10.1177/09610006251389997",
      "id": "WOS:001613229100001",
      "n": 1
    },
    {
      "type": "journal",
      "year": 2025,
      "authors": "K.T., Naheem; Mir, Aasif Ahmad",
      "title": "Landscape of Research Data Repositories (RDRs) from Asian Countries: Insights from the re3data Registry",
      "source": "Journal of Library Metadata",
      "month": "Mar",
      "scopus": 0,
      "wos": 0,
      "doi": "10.1080/19386389.2025.2482469",
      "id": "RC:138422261_S24",
      "n": 2
    },
    {
      "type": "journal",
      "year": 2024,
      "authors": "Naheem, K. T.; Mir, Aasif Ahmad",
      "title": "Analyzing research data repositories (RDR) from BRICS nations: a comprehensive study",
      "source": "Library Management",
      "month": "Aug",
      "scopus": 5,
      "wos": 3,
      "doi": "10.1108/LM-04-2024-0040",
      "id": "WOS:001247217300001",
      "n": 3
    },
    {
      "type": "journal",
      "year": 2024,
      "authors": "Abdul Gafoor, C.P.; Perumbalath, Shamshadali ... Naheem, K.T.",
      "title": "Trends and patterns in green finance research: A bibliometric study",
      "source": "Innovation and Green Development",
      "month": "Jun",
      "scopus": 46,
      "wos": 24,
      "doi": "10.1016/J.IGD.2023.100119",
      "id": "RC:138330983_S24",
      "n": 4
    },
    {
      "type": "journal",
      "year": 2023,
      "authors": "Lund, Brady D.; Naheem, K. T.",
      "title": "Can ChatGPT be an author? A study of artificial intelligence authorship policies in top academic journals",
      "source": "Learned Publishing",
      "month": "Sep",
      "scopus": 93,
      "wos": 75,
      "doi": "10.1002/LEAP.1582",
      "id": "WOS:001071474800001",
      "award": "Wiley Top Cited Article (published 2023)",
      "n": 5
    },
    {
      "type": "journal",
      "year": 2022,
      "authors": "Naheem, K. T.; Sivaraman, P.",
      "title": "Authorship Pattern and Research Collaboration in the Field of Synthetic Biology",
      "source": "Qualitative & Quantitative Methods in Libraries",
      "month": "Dec",
      "wos": 3,
      "id": "WOS:001165596000006",
      "n": 6
    },
    {
      "type": "journal",
      "year": 2022,
      "authors": "Naheem, K. T.; Sivaraman, P.; Saravanan, G.",
      "title": "A Scientometric Analysis of Global Synthetic Biology Literature",
      "source": "Qualitative & Quantitative Methods in Libraries",
      "month": "Sep",
      "wos": 1,
      "id": "WOS:000886539200002",
      "n": 7
    },
    {
      "type": "journal",
      "year": 2022,
      "authors": "Naheem, K. T.; Sivaraman, P.; Saravanan, G.",
      "title": "Citation Distributions in Synthetic Biology Literature Output During 2005-2019",
      "source": "Qualitative & Quantitative Methods in Libraries",
      "month": "Jun",
      "wos": 1,
      "id": "WOS:000822271800004",
      "n": 8
    },
    {
      "type": "journal",
      "year": 2021,
      "authors": "Naheem K.T.; Sivaraman, P.; Saravanan, G.",
      "title": "Application of Bradford’s law of scattering to synthetic biology literature",
      "source": "Library Philosophy and Practice, 1–15",
      "scopus": 0,
      "n": 9
    },
    {
      "type": "journal",
      "year": 2020,
      "authors": "Naheem K.T.; Sivaraman, P.; Saravanan, G.",
      "title": "Lotka’s law and authorship distribution pattern in global synthetic biology literature",
      "source": "Library Philosophy and Practice",
      "n": 10
    },
    {
      "type": "journal",
      "year": 2020,
      "authors": "Naheem K.T.",
      "title": "Copyright literacy of library and information science professionals in India",
      "source": "Journal of Information and Knowledge, 57(1), 27–33",
      "n": 11
    },
    {
      "type": "journal",
      "year": 2019,
      "authors": "Naheem K.T.; Sivaraman, P.; Saravanan, G.",
      "title": "Application of Lotka’s law in Bell’s palsy (facial paralysis) research output during 2004-2018",
      "source": "Library Philosophy and Practice, 2892",
      "scopus": 3,
      "n": 12
    },
    {
      "type": "journal",
      "year": 2019,
      "authors": "Naheem K.T.; Sivaraman, P.; Saravanan, G.",
      "title": "Applicability of Lotka’s law in parasitology research output of India",
      "source": "Library Philosophy and Practice, 2958",
      "scopus": 3,
      "n": 13
    },
    {
      "type": "journal",
      "year": 2019,
      "authors": "Naheem K.T.; Sivaraman, P.; Shibu, K. M.",
      "title": "Research productivity of Vector Control Research Center (VCRC), Puducherry, India: a scientometric analysis",
      "source": "Journal of Knowledge & Communication Management, 9(1), 19–28",
      "n": 14
    },
    {
      "type": "journal",
      "year": 2019,
      "authors": "Naheem K.T.; Sivaraman, P.; Saravanan, G.",
      "title": "A scientometric analysis of Indian research output in parasitology during 2007-2016",
      "source": "KELPRO Bulletin, 23(1), 32–46",
      "n": 15
    },
    {
      "type": "journal",
      "year": 2017,
      "authors": "Naheem K.T.; Nagalingam, U.; Ramesha, B.",
      "title": "Chronic liver disease (CLD) research in SAARC countries: a scientometric analysis of research output during 1996-2015",
      "source": "Annals of Library and Information Studies, 64(1), 59–68",
      "scopus": 7,
      "n": 16
    },
    {
      "type": "journal",
      "year": 2017,
      "authors": "Naheem K.T.; Saraswati Rao, M.",
      "title": "Webometric analysis of Telugu newspaper websites: an evaluative study using Alexa Internet",
      "source": "International Journal of Digital Library Services, 7(2), 26–32",
      "n": 17
    },
    {
      "type": "journal",
      "year": 2017,
      "authors": "Naheem K.T.; Shibu, K. M.",
      "title": "Research output and publication impact of Pondicherry Engineering College (PEC), Puducherry (1996–2015)",
      "source": "Journal of Knowledge & Communication Management, 7(1), 74–87",
      "n": 18
    },
    {
      "type": "journal",
      "year": 2016,
      "authors": "Naheem K.T.",
      "title": "Malayalam newspaper websites: a webometric study using Alexa Internet",
      "source": "International Journal of Digital Library Services, 6(3), 67–75",
      "n": 19
    },
    {
      "type": "journal",
      "year": 2016,
      "authors": "Naheem K.T.; Shibu, K. M.",
      "title": "Research productivity of Government Medical College Calicut (GMCC), Kerala",
      "source": "Journal of Knowledge & Communication Management, 6(2), 140–153",
      "n": 20
    },
    {
      "type": "journal",
      "year": 2016,
      "authors": "Naheem K.T.",
      "title": "Library Progress (International): a bibliometric study",
      "source": "Library Progress (International), 36(1), 43–53",
      "n": 21
    },
    {
      "type": "journal",
      "year": 2016,
      "authors": "Naheem K.T.",
      "title": "Library and information science journals with impact factor (IF): an empirical study with special reference to JCR 2015",
      "source": "LIS Today, 3(1-2), 50–56",
      "n": 22
    },
    {
      "type": "journal",
      "year": 2015,
      "authors": "Naheem K.T.; Shibu, K. M.",
      "title": "Authorship patterns and collaborative research in the Journal of Knowledge and Communication Management, 2011–2014",
      "source": "Journal of Knowledge & Communication Management, 5(2), 203–211",
      "n": 23
    },
    {
      "type": "journal",
      "year": 2005,
      "authors": "Naheem K.T.",
      "title": "Use of periodicals in College of Agriculture Library, Vellayani, Thiruvananthapuram: a user’s survey",
      "source": "KELPRO Bulletin, 9(1), 47–52",
      "n": 24
    },
    {
      "type": "chapter",
      "year": 2023,
      "authors": "Naheem K.T.; Sivaraman, P.",
      "title": "Highly cited articles in chatbot technology research: a bibliometric analysis",
      "source": "In Role of Public Libraries in Creating Knowledge Society, Vivekanandha International Book Publishers, pp. 186–192",
      "n": 25
    },
    {
      "type": "chapter",
      "year": 2022,
      "authors": "Naheem K.T.; Sivaraman, P.",
      "title": "Education for sustainable development: a scientometric analysis",
      "source": "In Education for Sustainable Development, Vol. 1, IQAC, Annamalai University, pp. 484–502",
      "n": 26
    },
    {
      "type": "chapter",
      "year": 2022,
      "authors": "Naheem K.T.; Sivaraman, P.",
      "title": "Self-citation behavior of selected universities in Tamil Nadu, India",
      "source": "In Recent Perspectives on Technology Transfer in Library Science Education, Annamalai University, pp. 186–192",
      "n": 27
    },
    {
      "type": "chapter",
      "year": 2019,
      "authors": "Naheem K.T.; Sivaraman, P.; Saravanan, G.",
      "title": "Authorship and collaboration pattern in Indian Journal of Human Genetics (2005-2014): a bibliometric study",
      "source": "In Visualising Library Services in 2030, CMC Vellore, pp. 367–377",
      "n": 28
    },
    {
      "type": "chapter",
      "year": 2019,
      "authors": "Naheem K.T.; Sivaraman, P.; Saravanan, G.",
      "title": "Authorship pattern and collaboration in Indian parasitology research output",
      "source": "In Enhancement of Technology and Innovations in Contemporary Libraries, Alagappa University, pp. 220–224",
      "n": 29
    },
    {
      "type": "chapter",
      "year": 2017,
      "authors": "Naheem K.T.",
      "title": "Tools for information literacy instruction in Web 2.0 environment: an overview",
      "source": "In Recent Advances in Library and Information Science in Digital Era, Prateeksha Publications, pp. 221–228",
      "n": 30
    },
    {
      "type": "chapter",
      "year": 2016,
      "authors": "Naheem K.T.",
      "title": "Performance Measurement and Metrics (PMM) journal (2005-2014): a bibliometric analysis",
      "source": "In Library Management in 21st Century: Issues and Challenges, EssEss Publications, pp. 73–88",
      "n": 31
    },
    {
      "type": "chapter",
      "year": 2014,
      "authors": "Muthu, M.; Naheem K.T.; Sreenivasulu, M.",
      "title": "Leadership, professionalism and their strategies for LIS services in modern era",
      "source": "In Dynamics of E-Resources and Digital Libraries, Avon Publication, pp. 186–192",
      "n": 32
    },
    {
      "type": "conference",
      "year": 2026,
      "authors": "Naheem K.T.",
      "title": "Public funding for open access: an empirical assessment of article processing charge (APC) support under One Nation One Subscription (ONOS) India",
      "source": "KAKE 2026, International Conference on Knowledge Access to Knowledge Equity: Libraries’ Contribution to a Sustainable Nation (Viksit Bharat), Pondicherry University, 29–31 October 2026",
      "award": "Best Paper Award, Professional Category",
      "extra": "Paper ID 196, Technical Session 8",
      "n": 33
    },
    {
      "type": "conference",
      "year": 2025,
      "authors": "Vijayakumar, M.; Sahoo, J.; Naheem K.T.",
      "title": "Artificial intelligence literacy among research scholars: a study",
      "source": "14th International CALIBER 2025, Sri Venkateswara University, Tirupati, 17–19 November 2025, INFLIBNET Centre",
      "n": 34
    },
    {
      "type": "conference",
      "year": 2024,
      "authors": "Shibu, K. M.; Sevukan, R.; Naheem K.T.; Manne, S. R.",
      "title": "Gender differences in social media usage by the academic community",
      "source": "Proceedings of the G20 Library Summit, Vol. II, pp. 185–190",
      "n": 35
    },
    {
      "type": "conference",
      "year": 2015,
      "authors": "Naheem K.T.",
      "title": "Perceptions of library professionals towards the technology skills and competencies for modern librarianship: a survey",
      "source": "International Conference ICIDL 2015, SRM University, pp. 907–914",
      "n": 36
    },
    {
      "type": "conference",
      "year": 2015,
      "authors": "Naheem K.T.",
      "title": "Authorship patterns and collaborative research in Performance Measurement and Metrics journal, 2005–2014",
      "source": "National Conference SALIS 2015, B.S. Abdur Rahman University, pp. 69–73",
      "n": 37
    },
    {
      "type": "conference",
      "year": 2015,
      "authors": "Naheem K.T.",
      "title": "Authorship patterns and collaborative research in the Library Quarterly journal, 1995–2014",
      "source": "National Conference on Future Libraries, Gandhigram Rural Institute, pp. 602–606",
      "n": 38
    },
    {
      "type": "conference",
      "year": 2015,
      "authors": "Vijayakumar, P.; Naheem K.T.",
      "title": "Indian Journal of Radiology and Imaging: a bibliometric study (2009–2013)",
      "source": "UGC National Seminar on Advancement of Science through Scientometrics, Annamalai University, pp. 450–454",
      "n": 39
    },
    {
      "type": "conference",
      "year": 2015,
      "authors": "Abdul Rasheed, A.; Naheem K.T.",
      "title": "Web scale discovery services: a stepping stone to new generation catalogue",
      "source": "National Conference on Knowledge Discovery Management, University of Calicut, pp. 263–265",
      "n": 40
    },
    {
      "type": "conference",
      "year": 2015,
      "authors": "Naheem K.T.; Abdul Rasheed, A.; Baskar, M.",
      "title": "Google Apps for personal knowledge management (PKM)",
      "source": "International Conference on Emerging Technologies and Future of Libraries, Gulbarga University, pp. 132–136",
      "n": 41
    },
    {
      "type": "conference",
      "year": 2015,
      "authors": "Naheem K.T.; Abdul Rasheed, A.; Baskar, M.",
      "title": "Web 2.0 tools for information literacy instruction",
      "source": "National Seminar on Information Literacy Skills in the Digital Era, Alagappa University, pp. 112–114",
      "n": 42
    },
    {
      "type": "conference",
      "year": 2015,
      "authors": "Baskar, M.; Naheem K.T.",
      "title": "Electronic resource management in academic libraries: an introduction",
      "source": "National Conference on Advancement in LIS and Technology, B.S. Abdur Rahman University, pp. 414–416",
      "n": 43
    },
    {
      "type": "conference",
      "year": 2014,
      "authors": "Naheem K.T.; Baskar, M.",
      "title": "Personal knowledge management (PKM): an overview",
      "source": "National Seminar on Knowledge Management in Electronic Environment, Alagappa University, pp. 71–74",
      "n": 44
    },
    {
      "type": "conference",
      "year": 2014,
      "authors": "Baskar, M.; Naheem K.T.",
      "title": "Content management systems: an overview",
      "source": "National Seminar on Electronic Information Management and Dissemination, Periyar University, pp. 670–677",
      "n": 45
    },
    {
      "type": "conference",
      "year": 2014,
      "authors": "Abdul Rasheed, A.; Naheem K.T.",
      "title": "Information literacy, media literacy and digital literacy in the digital world: an overview",
      "source": "National Seminar on Mass Communication, St. Stephen’s College, pp. 73–77",
      "n": 46
    },
    {
      "type": "conference",
      "year": 2006,
      "authors": "Naheem K.T.; Saiju, D. I.",
      "title": "Admission seeking variables of library and information science students in Kerala: a socio-economic profile",
      "source": "XXII IATLIS National Conference, Bishop Heber College, pp. 71–74",
      "n": 47
    }
  ],
  "experience": [
    {
      "role": "Professional Assistant, Central Library",
      "org": "Pondicherry University",
      "period": "2011 to present",
      "points": [
        "Head of the Technical Processing Division: acquisition, cataloguing, classification, indexing and metadata",
        "Library office administration, including budgeting, procurement and documentation",
        "Compiles faculty publication data for NAAC and NIRF accreditation",
        "Key contributor to the VIDWAN–IRINS portal for faculty research profiling",
        "Liaison Officer for the School of Humanities"
      ]
    },
    {
      "role": "Junior Technician (Library)",
      "org": "IIT Madras",
      "period": "2009 to 2011",
      "points": [
        "Led RFID tagging of the Central Library collection",
        "Supported classification, cataloguing and barcoding",
        "Issued institutional-cum-library smart cards to students and faculty"
      ]
    },
    {
      "role": "Librarian Gr. IV",
      "org": "IHRD, Kerala",
      "period": "2006 to 2009",
      "points": [
        "Implemented library automation, including OPAC and automated circulation",
        "Started newspaper clipping and reading promotion services"
      ]
    }
  ],
  "education": [
    {
      "q": "Ph.D.",
      "s": "Library & Information Science, Annamalai University, Tamil Nadu",
      "y": "2022"
    },
    {
      "q": "M.Phil.",
      "s": "Library & Information Science, Kerala University",
      "y": "2007"
    },
    {
      "q": "MLISc",
      "s": "Library & Information Science, Kerala University",
      "y": "2005"
    },
    {
      "q": "BLISc",
      "s": "Library & Information Science, Calicut University",
      "y": "2002"
    },
    {
      "q": "B.A.",
      "s": "Arabic & Islamic History, Calicut University",
      "y": "2001"
    },
    {
      "q": "UGC-NET",
      "s": "Library & Information Science, UGC",
      "y": "2012"
    },
    {
      "q": "P.G.D.LAN",
      "s": "Library Automation & Networking, Pondicherry University",
      "y": "2013"
    },
    {
      "q": "SWAYAM certificate",
      "s": "Library Automation & Digitisation, IGNOU",
      "y": "2019"
    }
  ],
  "skills": [
    {
      "area": "Integrated library management",
      "tools": "VTLS Virtua, LibSys, Koha, automated circulation, OPAC"
    },
    {
      "area": "Digital libraries",
      "tools": "DSpace, Greenstone, CMS"
    },
    {
      "area": "Research analysis",
      "tools": "Scopus, Web of Science, Google Scholar, h-index, citation analysis"
    },
    {
      "area": "Research tools",
      "tools": "Plagiarism detection, Zotero, Mendeley"
    },
    {
      "area": "Academic data management",
      "tools": "VIDWAN–IRINS portal for NIRF and NAAC"
    }
  ],
  "training": [
    "MANLIBNET 5-day International Virtual Librarian Development Programme, Hyderabad (2020)",
    "International FDP on Libraries Response to COVID-19, SNDT Women’s University, Mumbai (2020)",
    "Advanced Training Programme on Bibliometrics and Research Output Analysis, INFLIBNET, Gujarat (2020)",
    "FDP on Statistical Applications using SPSS, G.L. Education Foundation, Bengaluru (2020)"
  ],
  "peerReview": {
    "note": "Only journal and publisher details are listed, to keep reviews confidential.",
    "rows": [
      {
        "journal": "Learned Publishing",
        "publisher": "Wiley, for the Association of Learned and Professional Society Publishers (ALPSP)",
        "issn": "Online ISSN 1741-4857",
        "url": "https://onlinelibrary.wiley.com/journal/17414857"
      },
      {
        "journal": "DESIDOC Journal of Library & Information Technology",
        "publisher": "DRDO",
        "issn": "e-ISSN 0976-4658",
        "url": "https://publicationsdrdo.in/index.php/djlit"
      },
      {
        "journal": "Journal of Geointerface",
        "publisher": "CEHESH Trust of India (peer-reviewed, open access, biannual)",
        "issn": "e-ISSN 2583-6900",
        "url": "https://cehesh.in/"
      }
    ]
  },
  "awards": [
    {
      "year": "2026",
      "text": "Best Paper Award, Professional Category, Technical Session 8, KAKE 2026 International Conference, Pondicherry University (29–31 October 2026), for the paper on APC support under One Nation One Subscription (ONOS) India"
    },
    {
      "year": "2025",
      "text": "Certificate of Excellence in Reviewing 2025, DESIDOC Journal of Library & Information Technology (DRDO, Defence R&D Organisation, Delhi), awarded December 2025 in recognition of outstanding contribution to the quality of the journal"
    },
    {
      "year": "2025",
      "text": "Mr. R. Boopathi – Mrs. Venda National Best Librarian Award, 2025, Madras Library Association"
    },
    {
      "year": "2023",
      "text": "Top Cited Article recognition, Wiley (Learned Publishing), for “Can ChatGPT be an author? A study of artificial intelligence authorship policies in top academic journals” (among work published in 2023)"
    },
    {
      "year": "2012",
      "text": "Recognized by SALIS Pondicherry Chapter for qualifying UGC-NET in Library & Information Science (2012)"
    }
  ],
  "committees": [
    "IASLIC XXV National Seminar (2012)",
    "Capacity Building Programme for Public Library Personnel (2023)",
    "G20 Library Summit (2024)",
    "Media Matters National Symposium (2024)"
  ],
  "memberships": [
    "Kerala Library Association (KLA)",
    "Madras Library Association (MALA)",
    "Society for the Advancement of Library and Information Science (SALIS)",
    "Indian Association of Special Libraries and Information Centres (IASLIC)"
  ],
  "credit": {
    "compiledBy": "Dr. Naheem KT, ARP Library, Pondicherry University",
    "links": [
      {
        "label": "ORCID",
        "url": "https://orcid.org/0000-0002-0623-8090"
      },
      {
        "label": "Academic Profile",
        "url": "https://drive.google.com/file/d/1eQLd3bOzJC5fr1tAxnx0Xx8hmKRrK4Kr/view"
      },
      {
        "label": "YouTube: Research Help Desk",
        "url": "https://www.youtube.com/@ResearchHelpDesk"
      }
    ],
    "sources": "Compiled from Web of Science, Scopus and Google Scholar"
  }
};
